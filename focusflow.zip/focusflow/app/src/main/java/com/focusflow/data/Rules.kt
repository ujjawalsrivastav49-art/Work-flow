package com.focusflow.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Per-app detection rules. All of it comes from detection_rules.json, never hard-coded. */
data class AppRule(
    val pkg: String,
    val label: String,
    /** "filter" = open normally, block Shorts/Reels. "intention" = 10-second check first. */
    val mode: String,
    val shortsViewIds: List<String>,
    val shortsTabLabels: List<String>,
    val shortsPhrases: List<String>,
    val watchViewIds: List<String>,
    val titleViewIds: List<String>
)

class Rules(
    val apps: Map<String, AppRule>,
    val alwaysAllowed: Set<String>,
    private val studyKeywords: List<String>,
    private val studyChannels: List<String>
) {
    fun isStudyTitle(title: String): Boolean {
        val t = title.lowercase()
        return studyKeywords.any { t.contains(it.lowercase()) } ||
            studyChannels.any { t.contains(it.lowercase()) }
    }

    fun mentionsStudyChannel(text: String): Boolean {
        val t = text.lowercase()
        return studyChannels.any { t.contains(it.lowercase()) }
    }

    companion object {
        private const val FILE = "detection_rules.json"

        /**
         * Loads rules from filesDir/detection_rules.json if present (this is the
         * "remote-updatable" hook: a downloader can drop a fresh copy there), otherwise
         * from the bundled asset. A broken override falls back to the asset.
         */
        fun load(context: Context): Rules {
            val override = File(context.filesDir, FILE)
            val overrideText = runCatching { if (override.exists()) override.readText() else null }.getOrNull()
            if (overrideText != null) {
                runCatching { return parse(overrideText) }
            }
            return parse(readAsset(context))
        }

        private fun readAsset(context: Context): String =
            context.assets.open(FILE).bufferedReader().use { it.readText() }

        private fun parse(text: String): Rules {
            val root = JSONObject(text)
            val appsObj = root.getJSONObject("apps")
            val map = HashMap<String, AppRule>()
            for (pkg in appsObj.keys()) {
                val o = appsObj.getJSONObject(pkg)
                map[pkg] = AppRule(
                    pkg = pkg,
                    label = o.optString("label", pkg),
                    mode = o.optString("mode", "filter"),
                    shortsViewIds = o.optJSONArray("shortsViewIds").strings(),
                    shortsTabLabels = o.optJSONArray("shortsTabLabels").strings(),
                    shortsPhrases = o.optJSONArray("shortsPhrases").strings(),
                    watchViewIds = o.optJSONArray("watchViewIds").strings(),
                    titleViewIds = o.optJSONArray("titleViewIds").strings()
                )
            }
            return Rules(
                apps = map,
                alwaysAllowed = root.optJSONArray("alwaysAllowed").strings().toSet(),
                studyKeywords = root.optJSONArray("studyKeywords").strings(),
                studyChannels = root.optJSONArray("studyChannels").strings()
            )
        }
    }
}

private fun JSONArray?.strings(): List<String> =
    if (this == null) emptyList() else List(length()) { optString(it) }
