package com.focusflow.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import com.focusflow.MainActivity
import com.focusflow.R
import com.focusflow.data.FocusState
import com.focusflow.data.Phase
import com.focusflow.ui.fmtClock

/** Keeps the session timer alive and counts focus time, behind one quiet notification. */
class FocusForegroundService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastTick = 0L
    private var carryMs = 0L
    private var ticks = 0

    private val tick = object : Runnable {
        override fun run() {
            try {
                onTick()
            } catch (t: Throwable) {
                Log.w(TAG, "tick failed", t)
            }
            if (FocusState.active) {
                handler.postDelayed(this, 1000L)
            } else {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        FocusState.init(this)
        ensureChannel()
        try {
            startForeground(NOTIF_ID, buildNotification())
        } catch (t: Throwable) {
            Log.w(TAG, "could not start foreground", t)
            stopSelf()
            return START_NOT_STICKY
        }
        lastTick = System.currentTimeMillis()
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    private fun onTick() {
        val now = System.currentTimeMillis()
        val delta = (now - lastTick).coerceIn(0L, 5000L)
        lastTick = now

        if (FocusState.phase(now) == Phase.FOCUS) {
            carryMs += delta
            val secs = carryMs / 1000L
            if (secs > 0) {
                FocusState.addFocusSeconds(secs)
                carryMs -= secs * 1000L
            }
        }
        if (++ticks % 5 == 0) {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
        }
    }

    private fun buildNotification(): Notification {
        val now = System.currentTimeMillis()
        val mode = FocusState.mode
        val text = when (FocusState.phase(now)) {
            Phase.FOCUS -> "Focus · ${fmtClock(FocusState.remainingMs(now))} left"
            Phase.BREAK -> "Break · ${fmtClock(FocusState.remainingMs(now))} left"
            Phase.IDLE -> "Ready"
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_focus)
            .setContentTitle("FocusFlow · ${mode.label}")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun ensureChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Focus session", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Quiet timer shown while a focus session runs"
                    setShowBadge(false)
                }
            )
        }
    }

    private companion object {
        const val TAG = "FocusService"
        const val CHANNEL_ID = "focus_session"
        const val NOTIF_ID = 42
    }
}
