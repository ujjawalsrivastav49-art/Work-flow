package com.focusflow

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focusflow.data.FocusState
import com.focusflow.data.Phase
import com.focusflow.ui.FocusBackground
import com.focusflow.ui.FocusOrb
import com.focusflow.ui.FocusTheme
import com.focusflow.ui.Glass
import com.focusflow.ui.PillButton
import com.focusflow.ui.paletteFor
import kotlinx.coroutines.delay

data class BlockRequest(
    val kind: String,
    val pkg: String,
    val label: String,
    val detail: String,
    val nonce: Long = System.nanoTime()
)

/**
 * The calm "Back to Focus" screen. Never shaming: one soft message, a goal reminder,
 * and always a way out (5-min break, Emergency).
 */
class BlockActivity : ComponentActivity() {

    private var request by mutableStateOf(BlockRequest("", "", "", ""))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FocusState.init(this)
        enableEdgeToEdge()
        request = readRequest(intent)

        // Back goes Home (not back into the distracting screen).
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goHome()
        })

        setContent {
            FocusTheme {
                BlockScreen(request, onHome = { goHome() }, onClose = { finish() })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        request = readRequest(intent)
    }

    private fun readRequest(i: Intent) = BlockRequest(
        kind = i.getStringExtra(EXTRA_KIND) ?: KIND_INTENTION,
        pkg = i.getStringExtra(EXTRA_PKG) ?: "",
        label = i.getStringExtra(EXTRA_LABEL) ?: "this app",
        detail = i.getStringExtra(EXTRA_DETAIL) ?: ""
    )

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }

    companion object {
        const val EXTRA_KIND = "kind"
        const val EXTRA_PKG = "pkg"
        const val EXTRA_LABEL = "label"
        const val EXTRA_DETAIL = "detail"
        const val KIND_SHORTS = "shorts"
        const val KIND_VIDEO = "video"
        const val KIND_INTENTION = "intention"
    }
}

private fun goalLine(): String {
    val left = FocusState.goalMinutes - (FocusState.focusSecondsToday() / 60).toInt()
    return if (left > 0) "You're $left min from today's goal." else "Daily goal reached. Nice work."
}

@Composable
private fun BlockScreen(req: BlockRequest, onHome: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current

    @Suppress("UNUSED_VARIABLE")
    val version = FocusState.version

    val mode = FocusState.mode
    val strict = mode.strict
    val palette = paletteFor(mode, Phase.FOCUS)
    val isIntention = req.kind == BlockActivity.KIND_INTENTION

    var secondsLeft by remember(req) { mutableIntStateOf(if (isIntention) 10 else 0) }
    var reason by remember(req) { mutableStateOf<String?>(null) }
    LaunchedEffect(req) {
        while (secondsLeft > 0) {
            delay(1000)
            secondsLeft -= 1
        }
    }

    val feature = if (req.pkg.contains("youtube")) "Shorts" else "Reels"
    val goal = goalLine()
    val title: String
    val body: String
    when (req.kind) {
        BlockActivity.KIND_SHORTS -> {
            title = "$feature are paused"
            body = "Study videos and search still work. $goal"
        }
        BlockActivity.KIND_VIDEO -> {
            title = "Is this for study?"
            body = "“${req.detail.take(80)}” doesn't look like study content. $goal"
        }
        else -> {
            title = "Why are you opening ${req.label}?"
            body = "Take a breath first. $goal"
        }
    }

    FocusBackground(palette) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 22.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(36.dp))
            FocusOrb(
                progress = if (isIntention) 1f - secondsLeft / 10f else 0f,
                accent = palette.accent,
                diameter = 180.dp,
                grow = 0.8f,
                wilt = 0f,
                ring = isIntention
            ) {
                Text(
                    if (isIntention && secondsLeft > 0) "$secondsLeft" else "breathe",
                    color = Color.White,
                    fontSize = if (isIntention && secondsLeft > 0) 40.sp else 16.sp,
                    fontWeight = FontWeight.Light
                )
            }
            Spacer(Modifier.height(24.dp))

            Glass(Modifier.fillMaxWidth()) {
                Text(title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text(body, color = Color.White.copy(alpha = 0.85f), fontSize = 16.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(18.dp))

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    when (req.kind) {
                        BlockActivity.KIND_SHORTS -> {
                            PillButton("Back to study", onHome, Modifier.fillMaxWidth(), filled = true)
                            PillButton("Back to ${req.label} (study only)", onClose, Modifier.fillMaxWidth())
                        }

                        BlockActivity.KIND_VIDEO -> {
                            PillButton("Go back to study", onHome, Modifier.fillMaxWidth(), filled = true)
                            if (!strict) {
                                PillButton("Yes, it's study", {
                                    FocusState.allowVideo(req.detail)
                                    FocusState.grantVideoPass(req.pkg, 10)
                                    onClose()
                                }, Modifier.fillMaxWidth())
                            }
                        }

                        else -> {
                            if (!strict) {
                                Row(
                                    Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf("Study-related", "Message someone", "Just bored").forEach { r ->
                                        PillButton(r, { reason = r }, filled = reason == r, compact = true)
                                    }
                                }
                            }
                            PillButton("Back to study", onHome, Modifier.fillMaxWidth(), filled = true)
                            if (!strict) {
                                PillButton(
                                    if (secondsLeft > 0) "Continue in ${secondsLeft}s" else "Continue for 5 min",
                                    {
                                        if (reason != "Study-related") FocusState.addSlip()
                                        FocusState.grantPass(req.pkg, 5)
                                        onClose()
                                    },
                                    Modifier.fillMaxWidth(),
                                    enabled = secondsLeft == 0 && reason != null
                                )
                            }
                        }
                    }

                    PillButton("5-min break", {
                        FocusState.pauseFor(5)
                        onClose()
                    }, Modifier.fillMaxWidth())

                    // Always available. Opens the dialer and pauses blocking for 15 minutes.
                    PillButton("Emergency · open dialer", {
                        FocusState.pauseFor(15)
                        runCatching {
                            ctx.startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                        onClose()
                    }, Modifier.fillMaxWidth())
                }
            }
        }
    }
}
