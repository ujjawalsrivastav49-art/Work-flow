package com.focusflow

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.focusflow.data.FocusMode
import com.focusflow.data.FocusState
import com.focusflow.data.Phase
import com.focusflow.service.FocusAccessibilityService
import com.focusflow.service.FocusForegroundService
import com.focusflow.ui.FocusBackground
import com.focusflow.ui.FocusOrb
import com.focusflow.ui.FocusTheme
import com.focusflow.ui.Glass
import com.focusflow.ui.PillButton
import com.focusflow.ui.fmtClock
import com.focusflow.ui.fmtDuration
import com.focusflow.ui.paletteFor
import kotlinx.coroutines.delay
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FocusState.init(this)
        enableEdgeToEdge()
        setContent { FocusTheme { HomeScreen() } }
    }
}

private val quotes = listOf(
    "Small steps, every day.",
    "Focus is a quiet kind of power.",
    "One chapter, then a breath.",
    "Future you is cheering for this session.",
    "Progress, not perfection.",
    "Deep work now, freedom later.",
    "You don't need motivation, just the next ten minutes.",
    "Calm mind, clear page."
)

@Composable
fun HomeScreen() {
    val ctx = LocalContext.current

    // Reading this makes the screen recompose whenever FocusState changes.
    @Suppress("UNUSED_VARIABLE")
    val version = FocusState.version

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var a11yOn by remember { mutableStateOf(isAccessibilityEnabled(ctx)) }
    var showDisclosure by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            a11yOn = isAccessibilityEnabled(ctx)
            delay(500)
        }
    }

    val mode = FocusState.mode
    val active = FocusState.active
    val phase = FocusState.phase(now)
    val progress = FocusState.progress(now)
    val palette = paletteFor(mode, phase)
    val slips = FocusState.slipsToday()

    fun startSession() {
        FocusState.start()
        runCatching {
            ContextCompat.startForegroundService(ctx, Intent(ctx, FocusForegroundService::class.java))
        }
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        // Start either way. The timer works without the notification being visible.
        startSession()
    }

    fun begin() {
        val needsAsk = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsAsk) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else startSession()
    }

    val timeText = if (mode == FocusMode.CHILL) "Chill" else fmtClock(FocusState.remainingMs(now))
    val subText = when (phase) {
        Phase.FOCUS -> "FOCUS · ${mode.label.uppercase()}"
        Phase.BREAK -> "BREAK · RECHARGE"
        Phase.IDLE ->
            if (mode == FocusMode.CHILL) "Everything allowed" else "Ready · ${mode.focusMin}/${mode.breakMin} min"
    }
    val grow = when (phase) {
        Phase.FOCUS -> 0.62f + 0.38f * progress
        Phase.BREAK -> 0.78f
        Phase.IDLE -> 0.62f
    }
    val wilt = (slips * 0.12f).coerceAtMost(0.5f)

    FocusBackground(palette) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Header
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("FocusFlow", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    quotes[LocalDate.now().dayOfYear % quotes.size],
                    color = Color.White.copy(alpha = 0.75f),
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
            }

            // Mode chips
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FocusMode.values().forEach { m ->
                    PillButton(
                        text = m.label,
                        onClick = { if (m != mode) FocusState.selectMode(m) },
                        filled = m == mode,
                        compact = true
                    )
                }
            }

            // Orb + timer
            FocusOrb(
                progress = if (phase == Phase.IDLE) 0f else progress,
                accent = palette.accent,
                diameter = 290.dp,
                grow = grow,
                wilt = wilt,
                ring = mode != FocusMode.CHILL
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        timeText,
                        color = Color.White,
                        fontSize = 54.sp,
                        fontWeight = FontWeight.Light,
                        style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.35f), blurRadius = 12f))
                    )
                    Text(subText, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                }
            }

            // Main action
            when {
                mode == FocusMode.CHILL ->
                    PillButton("Pick a mode to start focusing", {}, Modifier.fillMaxWidth(), enabled = false)
                active ->
                    PillButton("End session", { FocusState.stop() }, Modifier.fillMaxWidth())
                else ->
                    PillButton("Start focus", { begin() }, Modifier.fillMaxWidth(), filled = true)
            }

            // Stats
            val todaySec = FocusState.focusSecondsToday()
            val goal = FocusState.goalMinutes
            val pct = ((todaySec / 60f) / goal).coerceIn(0f, 1f)
            Glass(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Stat("Today", fmtDuration(todaySec))
                    Stat("Streak", "${FocusState.streakDays()} d")
                    GoalRing(pct, palette.accent)
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "Distractions caught: ${FocusState.blockedToday()}  ·  Slips: $slips",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            }

            // Permission / status
            if (!a11yOn) {
                Glass(Modifier.fillMaxWidth()) {
                    Text("Turn on smart blocking", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "FocusFlow needs the Accessibility permission to spot YouTube Shorts and Reels. " +
                            "It never reads passwords or messages, and nothing leaves your phone.",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 14.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    PillButton("Set up", { showDisclosure = true }, Modifier.fillMaxWidth(), filled = true)
                }
            } else {
                Text("Smart blocking is on", color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
            }

            Text(
                "Phone, SMS, Maps, Camera, Clock and Calculator are never blocked.",
                color = Color.White.copy(alpha = 0.55f),
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
        }
    }

    if (showDisclosure) {
        AlertDialog(
            onDismissRequest = { showDisclosure = false },
            title = { Text("Accessibility permission") },
            text = {
                Text(
                    "FocusFlow uses Android's Accessibility Service to see which app and screen is open " +
                        "(for example the YouTube Shorts tab) so it can guide you back to studying.\n\n" +
                        "• It does not read or store passwords, messages or what you type.\n" +
                        "• Nothing leaves your phone. There are no servers and no analytics.\n" +
                        "• You can turn it off any time in Settings.\n\n" +
                        "On the next screen, open Installed apps > FocusFlow and switch it on."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showDisclosure = false
                    ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }) { Text("Agree & open settings") }
            },
            dismissButton = {
                TextButton(onClick = { showDisclosure = false }) { Text("Not now") }
            }
        )
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
        Text(label, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
    }
}

@Composable
private fun GoalRing(fraction: Float, accent: Color) {
    Box(Modifier.size(76.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(76.dp)) {
            val stroke = 8.dp.toPx()
            drawCircle(Color.White.copy(alpha = 0.15f), radius = this.size.minDimension / 2f - stroke / 2f, style = Stroke(stroke))
            drawArc(
                color = accent,
                startAngle = -90f,
                sweepAngle = 360f * fraction,
                useCenter = false,
                topLeft = Offset(stroke / 2f, stroke / 2f),
                size = Size(this.size.width - stroke, this.size.height - stroke),
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
        }
        Text("${(fraction * 100).toInt()}%", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

fun isAccessibilityEnabled(ctx: Context): Boolean {
    val enabled = Settings.Secure.getString(
        ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    val me = ComponentName(ctx, FocusAccessibilityService::class.java)
    return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
}
