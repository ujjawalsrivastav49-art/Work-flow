package com.focusflow.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import java.time.LocalDate

enum class FocusMode(val label: String, val focusMin: Int, val breakMin: Int, val strict: Boolean) {
    STUDY("Study", 25, 5, false),
    DEEP("Deep Work", 50, 10, true),
    EXAM("Exam", 50, 10, true),
    CHILL("Chill", 0, 0, false)
}

enum class Phase { FOCUS, BREAK, IDLE }

/**
 * Single source of truth, shared by the UI, the accessibility service and the
 * foreground service (all run in the same process). Everything is stored on-device
 * in SharedPreferences. No network, no analytics.
 */
object FocusState {
    private var prefs: SharedPreferences? = null
    private val allowedVideos = HashSet<String>()

    /** Bumped on every change so Compose screens recompose. */
    var version by mutableIntStateOf(0)
        private set

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences("focusflow", Context.MODE_PRIVATE)
        }
    }

    private fun bump() {
        version++
    }

    private fun getLong(key: String): Long = prefs?.getLong(key, 0L) ?: 0L
    private fun putLong(key: String, value: Long) {
        prefs?.edit()?.putLong(key, value)?.apply()
    }

    // ---------------------------------------------------------------- session

    val mode: FocusMode
        get() = runCatching { FocusMode.valueOf(prefs?.getString("mode", null) ?: "STUDY") }
            .getOrDefault(FocusMode.STUDY)

    val active: Boolean
        get() = prefs?.getBoolean("active", false) ?: false

    private val startedAt: Long
        get() = getLong("startedAt")

    var goalMinutes: Int
        get() = prefs?.getInt("goal", 120) ?: 120
        set(value) {
            prefs?.edit()?.putInt("goal", value)?.apply()
            bump()
        }

    fun selectMode(m: FocusMode) {
        prefs?.edit()?.putString("mode", m.name)?.apply()
        when {
            m == FocusMode.CHILL -> stop()
            active -> start(m)
            else -> bump()
        }
    }

    fun start(m: FocusMode = mode) {
        if (m == FocusMode.CHILL) return
        prefs?.edit()
            ?.putString("mode", m.name)
            ?.putBoolean("active", true)
            ?.putLong("startedAt", System.currentTimeMillis())
            ?.putLong("pauseUntil", 0L)
            ?.apply()
        allowedVideos.clear()
        bump()
    }

    fun stop() {
        prefs?.edit()?.putBoolean("active", false)?.apply()
        bump()
    }

    // ------------------------------------------------------- pomodoro timeline

    private data class Pos(val phase: Phase, val elapsed: Long, val length: Long)

    private fun pos(now: Long): Pos {
        val m = mode
        if (!active || m == FocusMode.CHILL) {
            return Pos(Phase.IDLE, 0L, m.focusMin.coerceAtLeast(1) * 60_000L)
        }
        val focusLen = m.focusMin * 60_000L
        val breakLen = m.breakMin * 60_000L
        val p = (now - startedAt).coerceAtLeast(0L) % (focusLen + breakLen)
        return if (p < focusLen) Pos(Phase.FOCUS, p, focusLen) else Pos(Phase.BREAK, p - focusLen, breakLen)
    }

    fun phase(now: Long = System.currentTimeMillis()): Phase = pos(now).phase

    fun remainingMs(now: Long = System.currentTimeMillis()): Long =
        pos(now).let { it.length - it.elapsed }

    fun progress(now: Long = System.currentTimeMillis()): Float =
        pos(now).let { (it.elapsed.toFloat() / it.length).coerceIn(0f, 1f) }

    // ------------------------------------------------------------ enforcement

    /** Blocking only runs during the focus part of an active, non-chill session. */
    fun shouldEnforce(now: Long = System.currentTimeMillis()): Boolean =
        phase(now) == Phase.FOCUS && now >= getLong("pauseUntil")

    /** Short break or emergency: everything is allowed for a while. */
    fun pauseFor(minutes: Int) {
        putLong("pauseUntil", System.currentTimeMillis() + minutes * 60_000L)
        bump()
    }

    /** Pass for "intention" apps (Snapchat etc.) after the 10-second check. */
    fun grantPass(pkg: String, minutes: Int) =
        putLong("pass_$pkg", System.currentTimeMillis() + minutes * 60_000L)

    fun hasPass(pkg: String, now: Long = System.currentTimeMillis()): Boolean =
        now < getLong("pass_$pkg")

    /** Pass that only skips the "is this study?" video check, never the Shorts block. */
    fun grantVideoPass(pkg: String, minutes: Int) =
        putLong("vpass_$pkg", System.currentTimeMillis() + minutes * 60_000L)

    fun hasVideoPass(pkg: String, now: Long = System.currentTimeMillis()): Boolean =
        now < getLong("vpass_$pkg")

    fun allowVideo(title: String) {
        allowedVideos.add(title.trim().lowercase())
    }

    fun isVideoAllowed(title: String): Boolean = allowedVideos.contains(title.trim().lowercase())

    // ------------------------------------------------------------------ stats

    private fun today(): String = LocalDate.now().toString()

    private fun focusSecondsOn(day: String): Long = getLong("focus_$day")

    fun focusSecondsToday(): Long = focusSecondsOn(today())

    fun addFocusSeconds(seconds: Long) {
        if (seconds > 0) putLong("focus_${today()}", focusSecondsToday() + seconds)
    }

    fun blockedToday(): Int = getLong("blocked_${today()}").toInt()

    fun addBlocked() {
        putLong("blocked_${today()}", blockedToday() + 1L)
        bump()
    }

    fun slipsToday(): Int = getLong("slips_${today()}").toInt()

    fun addSlip() {
        putLong("slips_${today()}", slipsToday() + 1L)
        bump()
    }

    /** Consecutive days with at least 10 minutes of focus. Today doesn't break it until it's over. */
    fun streakDays(): Int {
        var day = LocalDate.now()
        if (focusSecondsOn(day.toString()) < 600) day = day.minusDays(1)
        var n = 0
        while (n < 365 && focusSecondsOn(day.toString()) >= 600) {
            n++
            day = day.minusDays(1)
        }
        return n
    }
}
