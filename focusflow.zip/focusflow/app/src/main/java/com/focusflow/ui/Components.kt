package com.focusflow.ui

import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focusflow.data.FocusMode
import com.focusflow.data.Phase

// ------------------------------------------------------------------ theme

/** Material You colors on Android 12+, a dark scheme otherwise. Backgrounds are our own gradients. */
@Composable
fun FocusTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val scheme = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        dynamicDarkColorScheme(ctx)
    } else {
        darkColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

data class Palette(val top: Color, val bottom: Color, val accent: Color)

/** Calm blue = study, deep purple = deep work, warm red = exam, green = chill, orange = break. */
fun paletteFor(mode: FocusMode, phase: Phase): Palette {
    if (phase == Phase.BREAK) {
        return Palette(Color(0xFF5C2A0F), Color(0xFFE07B2B), Color(0xFFFFC48A))
    }
    return when (mode) {
        FocusMode.STUDY -> Palette(Color(0xFF0F2A5C), Color(0xFF2B6CB0), Color(0xFF7CC4FF))
        FocusMode.DEEP -> Palette(Color(0xFF1A0B3B), Color(0xFF5B2A9E), Color(0xFFC4A1FF))
        FocusMode.EXAM -> Palette(Color(0xFF3B0B14), Color(0xFF9E2A3C), Color(0xFFFF9EAD))
        FocusMode.CHILL -> Palette(Color(0xFF0B3B33), Color(0xFF2A9E7A), Color(0xFF8CFFD9))
    }
}

// ------------------------------------------------------------- formatting

fun fmtClock(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) + 999L) / 1000L
    return "%02d:%02d".format(total / 60, total % 60)
}

fun fmtDuration(seconds: Long): String {
    val m = seconds / 60
    return if (m >= 60) "${m / 60}h ${"%02d".format(m % 60)}m" else "${m}m"
}

// ------------------------------------------------------------ background

@Composable
fun FocusBackground(palette: Palette, content: @Composable BoxScope.() -> Unit) {
    val top by animateColorAsState(palette.top, tween(900), label = "top")
    val bottom by animateColorAsState(palette.bottom, tween(900), label = "bottom")
    val accent by animateColorAsState(palette.accent, tween(900), label = "accent")
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(top, bottom)))) {
        AmbientBlobs(accent)
        content()
    }
}

/** Two slowly drifting soft glows behind everything, for a living background. */
@Composable
private fun AmbientBlobs(accent: Color) {
    val t = rememberInfiniteTransition(label = "blobs")
    val a by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "a"
    )
    val b by t.animateFloat(
        1f, 0f, infiniteRepeatable(tween(19000, easing = LinearEasing), RepeatMode.Reverse), label = "b"
    )
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val c1 = Offset(w * (0.1f + 0.7f * a), h * (0.15f + 0.25f * b))
        val c2 = Offset(w * (0.9f - 0.7f * b), h * (0.85f - 0.25f * a))
        drawCircle(
            Brush.radialGradient(listOf(accent.copy(alpha = 0.32f), Color.Transparent), center = c1, radius = w * 0.7f),
            radius = w * 0.7f, center = c1
        )
        drawCircle(
            Brush.radialGradient(listOf(accent.copy(alpha = 0.22f), Color.Transparent), center = c2, radius = w * 0.8f),
            radius = w * 0.8f, center = c2
        )
    }
}

// ------------------------------------------------------------- glass card

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Column(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.18f), Color.White.copy(alpha = 0.07f))))
            .border(1.dp, Color.White.copy(alpha = 0.22f), shape)
            .padding(18.dp),
        content = content
    )
}

// ----------------------------------------------------------------- button

@Composable
fun PillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
    enabled: Boolean = true,
    compact: Boolean = false
) {
    val haptic = LocalHapticFeedback.current
    val shape = RoundedCornerShape(50)
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.95f else 1f, spring(dampingRatio = 0.5f), label = "press")
    Box(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .alpha(if (enabled) 1f else 0.45f)
            .clip(shape)
            .background(if (filled) Color.White.copy(alpha = 0.93f) else Color.White.copy(alpha = 0.14f))
            .border(1.dp, Color.White.copy(alpha = 0.25f), shape)
            .clickable(interactionSource = source, indication = null, enabled = enabled) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            }
            .padding(horizontal = if (compact) 16.dp else 22.dp, vertical = if (compact) 9.dp else 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (filled) Color(0xFF10223F) else Color.White,
            fontWeight = FontWeight.SemiBold,
            fontSize = if (compact) 14.sp else 16.sp
        )
    }
}

// -------------------------------------------------------------- focus orb

/**
 * The animated focus orb: it breathes, grows as the focus phase progresses, and
 * slowly loses color ("wilts") a little for each time the user gave in today.
 */
@Composable
fun FocusOrb(
    progress: Float,
    accent: Color,
    diameter: Dp,
    grow: Float,
    wilt: Float,
    ring: Boolean,
    content: @Composable BoxScope.() -> Unit
) {
    val infinite = rememberInfiniteTransition(label = "orb")
    val pulse by infinite.animateFloat(
        0.97f, 1.03f,
        infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val g by animateFloatAsState(grow, tween(1200), label = "grow")
    val p by animateFloatAsState(progress, tween(500), label = "progress")
    val color = lerp(accent, Color(0xFF8A8F98), wilt.coerceIn(0f, 0.6f))

    Box(Modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 9.dp.toPx()
            val maxR = this.size.minDimension / 2f
            if (ring) {
                drawCircle(Color.White.copy(alpha = 0.12f), radius = maxR - stroke, style = Stroke(stroke))
                drawArc(
                    color = color,
                    startAngle = -90f,
                    sweepAngle = 360f * p,
                    useCenter = false,
                    topLeft = Offset(stroke, stroke),
                    size = Size(this.size.width - stroke * 2, this.size.height - stroke * 2),
                    style = Stroke(stroke, cap = StrokeCap.Round)
                )
            }
            val r = (maxR - stroke * 4f) * g * pulse
            drawCircle(
                Brush.radialGradient(listOf(color.copy(alpha = 0.55f), Color.Transparent), center = center, radius = r * 1.5f),
                radius = r * 1.5f, center = center
            )
            drawCircle(
                Brush.radialGradient(
                    listOf(color.copy(alpha = 0.95f), color.copy(alpha = 0.62f)),
                    center = center - Offset(r * 0.2f, r * 0.25f), radius = r * 1.1f
                ),
                radius = r, center = center
            )
        }
        content()
    }
}
