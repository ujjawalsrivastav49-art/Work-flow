package com.focusflow.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.focusflow.BlockActivity
import com.focusflow.data.AppRule
import com.focusflow.data.FocusState
import com.focusflow.data.Rules

/**
 * Lets distracting apps open normally and only steps in when the screen shows
 * something the rules call a distraction (Shorts/Reels, a non-study video, or an
 * "intention" app like Snapchat).
 *
 * Golden rule: FAIL OPEN. Any exception, missing rule or unreadable screen means
 * "allow". The user is never locked out.
 */
class FocusAccessibilityService : AccessibilityService() {

    private var rules: Rules? = null
    private var lastScan = 0L
    private var lastBlock = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        FocusState.init(this)
        rules = runCatching { Rules.load(this) }.getOrNull()
    }

    override fun onInterrupt() = Unit

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try {
            handle(event)
        } catch (t: Throwable) {
            Log.w(TAG, "Detection failed, allowing the app", t)
        }
    }

    private fun handle(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        val r = rules ?: return
        FocusState.init(this)

        val wall = System.currentTimeMillis()
        if (!FocusState.shouldEnforce(wall)) return          // no session, break, chill or paused
        if (pkg in r.alwaysAllowed) return                   // phone, SMS, maps, camera...
        val rule = r.apps[pkg] ?: return                     // not a watched app

        val now = SystemClock.elapsedRealtime()
        if (now - lastBlock < BLOCK_COOLDOWN_MS) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            now - lastScan < SCAN_THROTTLE_MS
        ) return
        lastScan = now

        // Only act if the app we were told about is really the one on screen.
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return

        if (rule.mode == "intention") {
            if (!FocusState.hasPass(pkg, wall)) showBlock(BlockActivity.KIND_INTENTION, rule)
        } else {
            scanFilter(root, rule, r, wall)
        }
    }

    private fun scanFilter(root: AccessibilityNodeInfo, rule: AppRule, r: Rules, wall: Long) {
        // 1) Shorts / Reels: always blocked during focus.
        if (isShorts(root, rule)) {
            showBlock(BlockActivity.KIND_SHORTS, rule)
            return
        }

        // 2) Regular videos: allowed only if they look like study content.
        if (rule.watchViewIds.isEmpty() || FocusState.hasVideoPass(rule.pkg, wall)) return
        if (!anyVisible(root, rule.watchViewIds)) return
        val title = firstVisibleText(root, rule.titleViewIds) ?: return
        if (FocusState.isVideoAllowed(title)) return
        if (r.isStudyTitle(title) || r.mentionsStudyChannel(collectText(root))) return
        showBlock(BlockActivity.KIND_VIDEO, rule, title)
    }

    private fun isShorts(root: AccessibilityNodeInfo, rule: AppRule): Boolean {
        // Primary: known view IDs (from detection_rules.json).
        if (anyVisible(root, rule.shortsViewIds)) return true

        // Fallback: walk a limited number of nodes and look at text / descriptions.
        if (rule.shortsTabLabels.isEmpty() && rule.shortsPhrases.isEmpty()) return false
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var seen = 0
        while (queue.isNotEmpty() && seen < MAX_NODES) {
            val n = queue.removeFirst()
            seen++
            val label = "${n.text ?: ""} ${n.contentDescription ?: ""}"
            // A tab label such as "Shorts" only counts when that tab is the selected one.
            if (n.isSelected && rule.shortsTabLabels.any { label.contains(it, ignoreCase = true) }) return true
            if (rule.shortsPhrases.any { label.contains(it, ignoreCase = true) }) return true
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
        return false
    }

    private fun anyVisible(root: AccessibilityNodeInfo, ids: List<String>): Boolean =
        ids.any { id ->
            root.findAccessibilityNodeInfosByViewId(id)?.any { it.isVisibleToUser } == true
        }

    private fun firstVisibleText(root: AccessibilityNodeInfo, ids: List<String>): String? {
        for (id in ids) {
            val nodes = root.findAccessibilityNodeInfosByViewId(id) ?: continue
            for (n in nodes) {
                val t = n.text?.toString()
                if (n.isVisibleToUser && !t.isNullOrBlank()) return t
            }
        }
        return null
    }

    private fun collectText(root: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var seen = 0
        while (queue.isNotEmpty() && seen < MAX_NODES) {
            val n = queue.removeFirst()
            seen++
            n.text?.let { sb.append(it).append(' ') }
            n.contentDescription?.let { sb.append(it).append(' ') }
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
        return sb.toString()
    }

    private fun showBlock(kind: String, rule: AppRule, detail: String = "") {
        lastBlock = SystemClock.elapsedRealtime()
        // Leave the Shorts player first so the app isn't left sitting on it.
        if (kind == BlockActivity.KIND_SHORTS) performGlobalAction(GLOBAL_ACTION_BACK)
        FocusState.addBlocked()

        val intent = Intent(this, BlockActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION
            )
            putExtra(BlockActivity.EXTRA_KIND, kind)
            putExtra(BlockActivity.EXTRA_PKG, rule.pkg)
            putExtra(BlockActivity.EXTRA_LABEL, rule.label)
            putExtra(BlockActivity.EXTRA_DETAIL, detail)
        }
        startActivity(intent)
    }

    private companion object {
        const val TAG = "FocusAccessibility"
        const val BLOCK_COOLDOWN_MS = 2500L
        const val SCAN_THROTTLE_MS = 400L
        const val MAX_NODES = 250
    }
}
