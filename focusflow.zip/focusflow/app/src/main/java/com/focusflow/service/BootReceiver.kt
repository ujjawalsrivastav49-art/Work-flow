package com.focusflow.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.content.ContextCompat
import com.focusflow.data.FocusState

/**
 * Restarts the timer notification after a reboot if a session was running.
 * (The accessibility service itself is restored by Android, and reads the same saved state.)
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        try {
            FocusState.init(context)
            if (FocusState.active) {
                ContextCompat.startForegroundService(
                    context, Intent(context, FocusForegroundService::class.java)
                )
            }
        } catch (t: Throwable) {
            Log.w("FocusBoot", "could not restart session service", t)
        }
    }
}
