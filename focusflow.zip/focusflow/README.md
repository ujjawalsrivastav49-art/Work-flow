# FocusFlow

Study-focus app. Distracting apps open normally; FocusFlow only steps in when the screen shows
something distracting (YouTube Shorts, Instagram/Facebook Reels, a non-study video) or when you open
an "intention" app (Snapchat, TikTok).

## Build and run
1. Install Android Studio (Koala or newer) with Android SDK 34.
2. File > Open > select this `focusflow` folder, then let Gradle sync.
3. Run on a real phone (Android 8.0+). Emulators work but don't have YouTube/Instagram.
4. In the app tap **Set up**, agree to the disclosure, then Settings > Accessibility >
   Installed apps > **FocusFlow** > On.
5. Pick **Study**, tap **Start focus**, open YouTube, tap the Shorts tab.

If Gradle complains about the wrapper, use Android Studio's bundled Gradle (8.7+).

## Most likely thing to need fixing: detection rules
App screens change with every update. All detection lives in
`app/src/main/assets/detection_rules.json`, not in code:
- `shortsViewIds`: view IDs that only exist on the Shorts/Reels screen
- `shortsTabLabels`: bottom-tab labels (only count when that tab is selected)
- `watchViewIds` / `titleViewIds`: the YouTube watch page and the video title
- `studyKeywords` / `studyChannels`: what counts as study content

To check an ID: open the target app on the phone, then use Android Studio >
Tools > Layout Inspector (or `uiautomatorviewer`) and read the `resource-id` of the Shorts player.
Put an updated copy of the JSON at the app's `filesDir/detection_rules.json` to override the
bundled one without rebuilding.

If detection fails for any reason the app is allowed (fail open).

## Project layout
- `service/FocusAccessibilityService.kt` detection and block trigger
- `service/FocusForegroundService.kt` quiet timer notification, counts focus time
- `service/BootReceiver.kt` restarts the notification after reboot
- `data/FocusState.kt` modes, Pomodoro timeline, passes, stats (SharedPreferences, on-device only)
- `data/Rules.kt` loads `detection_rules.json`
- `BlockActivity.kt` calm "Back to Focus" screen (5-min break, Emergency)
- `MainActivity.kt` home screen: animated orb, modes, stats, permission setup
- `ui/Components.kt` gradients, glass cards, orb, buttons

## Not built yet
Room/Hilt, charts and history screens, badges/XP, friends and focus rooms, auto-schedule,
quick-settings tile and widget, strict-mode PIN and cool-down, per-app rule editor, exam countdown date.
